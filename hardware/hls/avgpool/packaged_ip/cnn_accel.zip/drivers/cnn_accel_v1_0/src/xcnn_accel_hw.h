// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of in_bram
//        bit 31~0 - in_bram[31:0] (Read/Write)
// 0x14 : Data signal of in_bram
//        bit 31~0 - in_bram[63:32] (Read/Write)
// 0x18 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCNN_ACCEL_CONTROL_ADDR_IN_BRAM_DATA 0x10
#define XCNN_ACCEL_CONTROL_BITS_IN_BRAM_DATA 64

// CTRL
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of cls_out
//        bit 7~0 - cls_out[7:0] (Read)
//        others  - reserved
// 0x14 : Control signal of cls_out
//        bit 0  - cls_out_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCNN_ACCEL_CTRL_ADDR_AP_CTRL      0x00
#define XCNN_ACCEL_CTRL_ADDR_GIE          0x04
#define XCNN_ACCEL_CTRL_ADDR_IER          0x08
#define XCNN_ACCEL_CTRL_ADDR_ISR          0x0c
#define XCNN_ACCEL_CTRL_ADDR_CLS_OUT_DATA 0x10
#define XCNN_ACCEL_CTRL_BITS_CLS_OUT_DATA 8
#define XCNN_ACCEL_CTRL_ADDR_CLS_OUT_CTRL 0x14

